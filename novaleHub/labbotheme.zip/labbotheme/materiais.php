<?php

/*

Template Name: Materiais

*/

?>

<?php get_header(); ?>

<?php get_template_part('parts/btn-whatsapp/whatsapp') ?>

    <div class="content">

        <?php

            get_template_part('parts/materiais/loop');

            get_template_part('parts/materiais/download');

            get_template_part('parts/materiais/tour');

            get_template_part('parts/materiais/links-uteis');

        ?> 

    </div>

<?php get_footer(); ?>