<?php 

/*

Template Name: Jornada

*/

?>
<style>
    .iframeJornada {
        border-radius: 8px;
        padding: 70px
    }
    .iframeJornada iframe{
        width: 100%;
        height: 120vh;
        position: relative;
    }

    @media (max-width: 768px) {
        .iframeJornada iframe{
            height: 72vw; 
        }
        
        .iframeJornada {
            padding: 0;        
        }
    }
</style>
<?php get_header(); ?>
<div class="iframeJornada" style="width: 100%; height:100%;">
    <iframe title="JORNADA EMPREENDEDORA JARAGUÁ DO SUL" frameborder="0" width="100%" src="https://view.genial.ly/64b9190ae0ceb10011f749b6" type="text/html" allowscriptaccess="always" allowfullscreen="true" scrolling="yes" allownetworking="all"></iframe> 
</div>
<?php get_footer(); ?>
