<div class="grid-container">
    <header class="header">
        header
    </header>
    <aside class="sidenav">
        <?php get_template_part('parts/menu/menu'); ?>
    </aside>
    <main class="main">