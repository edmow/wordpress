
<div class="btn-whatsapp">
<a href="https://api.whatsapp.com/send?phone=554733075374" target="_blank">
        <img src="/wp-content/uploads/2024/01/whatsapp_3670051.png" alt="botão whatsapp">
    </a>
</div>