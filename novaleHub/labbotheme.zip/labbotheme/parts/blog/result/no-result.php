<div class="no-result">
    <strong>
        Whoops! Não encontramos nenhum resultado para sua busca.
    </strong>
    <figure>
        <img src="<?php echo get_image('no-result.png')?>" alt="">
    </figure>
    <p>
        Tente utilizar outras palavras para encontrar o que está procurando e tente novamente.
    </p>
</div>