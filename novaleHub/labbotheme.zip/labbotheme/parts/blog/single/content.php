<style>
    article blockquote::before {
        background-image: url('<?php echo get_template_directory_uri(); ?>/assets/svg/icon-aspas.svg');
    }
</style>
<div class="content-inner">
    <div class="content-inner-header">
        <span class="category">
        <?php 
            $categories = get_the_category();
                            
            if (!empty($categories)) {
                echo esc_html($categories[0]->name); 
            } else {
                echo 'Sem categoria';
            }
            ?>
        </span>
        <span class="date"><?php echo get_the_date('d M. Y'); // Formata a data como "25 Apr. 2022" ?></span>
    </div>
  
    <div class="content-inner-body">
        <hr>
        <h1><?php the_title(); ?></h1>
        <span><?php echo get_the_excerpt(); ?></span>
        <hr>
        <div class="content-inner-entry">
            <?php the_content(); ?>
        </div>
    </div>
</div>