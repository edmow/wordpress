
<section class="loop loop-result">
    <hr> 
    <span class="title-realated">Não deixe de ler</span>
    <div class="loop-inner">
        <?php
    
            $args = array(
                'post_type'      => 'post', // Limita a busca apenas ao tipo de post 'post'
                'posts_per_page' => 4, // Número de posts por página
                'order' => 'DESC',     // Ordenação
                'post__not_in'   => array(get_the_ID()),
            );
            $wp_query = new WP_Query($args);
        if ($wp_query->have_posts()) :
            while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
    <article class="card">
        <figure>
            <a href="<?php the_permalink(); ?>">
                <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" alt="<?php the_title(); ?>">
            </a> 
        </figure>
        <div class="card-info">
            <a href="<?php the_permalink(); ?>" class="card-top">
                <span class="category">
                <?php 
                // Recupera as categorias do post atual
                $categories = get_the_category();
                
                // Verifica se há categorias associadas ao post
                if (!empty($categories)) {
                    // Exibe a primeira categoria
                    echo esc_html($categories[0]->name); 
                } else {
                    // Caso não haja categorias, exibe uma mensagem ou deixa em branco
                    echo 'Sem categoria';
                }
                ?>
                </span>
                <span class="date"><?php echo get_the_date('d M. Y'); // Formata a data como "25 Apr. 2022" ?></span>
            </a>
            <a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
            <a href="<?php the_permalink(); ?>"><p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p></a>
        </div>
    </article>
<?php endwhile; 

            wp_reset_postdata();
        else:
        endif;
        ?>
    </div>
</section>