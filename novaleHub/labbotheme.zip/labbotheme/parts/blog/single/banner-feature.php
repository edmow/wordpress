<div class="banner-featured-single">
<div style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>')" class="banner-featured-background">

</div>

</div>
