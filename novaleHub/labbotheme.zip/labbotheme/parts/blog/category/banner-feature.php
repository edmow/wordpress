<div class="banner-feature banner-feature-category">
    <?php
    $category = get_queried_object();
    $color = get_field('category_color', 'category_' . $category->term_id);


    $uri_paged = $_SERVER['REQUEST_URI'];
    $uri_paged = explode('/', $uri_paged);
    $uri_paged = $uri_paged[count($uri_paged) - 2];
    $paged = (!$uri_paged) ? 1 : $uri_paged;
    $paged = (int) $paged;

    $args = array(
        'posts_per_page' => 14, // Pegando dois posts
        'order' => 'DESC',
        'paged' => $paged,
        'cat' => $category->term_id, 
    );

    $wp_query = new WP_Query($args);

    if ($wp_query->have_posts()) :
        $post_count = 0; // Contador para separar posts

        while ($wp_query->have_posts()) : $wp_query->the_post();
            $post_count++;

            if ($post_count == 1) : ?>
                <style>
                    .banner-feature .left figure::before{
                        background: <?php echo $color;?>!important;
                    }
                    .banner-feature .left .arrow-button:hover{
                        background: <?php echo $color;?>!important;
                    }
                    .banner-feature-category .left .info .title-category-gray::before{
                        color: <?php echo $color;?>!important;
                    }
                </style>
                <div class="left">
                    
                    <div class="info">
                        <div class="title-category-gray">
                            <span><?php echo $category->name?></span>
                        </div>
                        <a href="<?php the_permalink(); ?>"><h1><?php the_title(); ?></h1></a>
                        <span><?php echo get_the_date('d.m.Y'); ?></span>
                        <a href="<?php the_permalink(); ?>"><p><?php echo wp_trim_words(get_the_content(), 20, '...'); ?></p></a>
                        <a class="arrow-button" href="<?php the_permalink(); ?>"><img src="<?php echo get_template_directory_uri().'/assets/svg/arrow-button.svg'; ?>"></a>
                    </div>
                    <figure>
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" alt="<?php the_title(); ?>">
                        </a>
                    </figure>
                </div>
            <?php elseif ($post_count == 2) : ?>
                <div class="right">
                    <figure>
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" alt="<?php the_title(); ?>">
                        </a>
                    </figure>
                    <div class="info">
                        <span><?php echo get_the_date('d.m.Y'); ?></span>
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    </div>
                </div>
            <?php endif;
        endwhile;

        wp_reset_postdata();
    endif; ?>
</div>
