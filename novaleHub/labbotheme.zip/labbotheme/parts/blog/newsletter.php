<?php
    $title = get_field('newsletter_title', 'option');
    $text = get_field('newsletter_text', 'option');
    $shortcode = get_field('newsletter_form', 'option');
    $image = get_field('newsletter_image', 'option');
?>
<style>
.newsletter .right .your-email::before{
    background-image: url('<?php echo get_template_directory_uri(); ?>/assets/svg/icon-email.svg');
}
.newsletter .right .your-name::before{
    background-image: url('<?php echo get_template_directory_uri(); ?>/assets/svg/icon-name.svg');
}
.newsletter::before{
    background-image: url(<?php echo $image['url']?>);
}
</style>
<section class="newsletter-outter">
    <div class="newsletter">
        <div class="left">
            <strong>
                <?php echo $title;?>
            </strong>
            <p>
                <?php echo $text;?>
            </p>
        </div>
        <div class="right">
            <?php 
                echo do_shortcode($shortcode);
            ?>
        </div>
    </div>
</section>