<?php    
    $category = get_queried_object();
    $color = get_field('category_color', 'category_' . $category->term_id);
    $current_category = get_queried_object();
    $current_category_id = $current_category->term_id;
?>
<style>
    .filter .category ul .active a{
        color: var(--white);
        background: <?php echo $color;?>!important;
    }
        
    .filter .category ul li a:hover{
        background: <?php echo $color;?>!important;
    }
</style>
<div class="filter">
    <div class="category">
    <?php
        // Obtém todas as categorias
        $categories = get_categories(array(
            'taxonomy' => 'category', // A taxonomia padrão para o post type 'post'
            'orderby' => 'name',
            'order'   => 'ASC'
        ));

        if (!empty($categories)): ?>
            <ul>
                <?php foreach ($categories as $category): ?>
                    <li class="<?php echo ($category->term_id === $current_category_id) ? 'active' : ''; ?>">
                        <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>">
                            <?php echo esc_html($category->name); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div> 
    <div class="search">
        <form action="/resultado-de-pesquisa" method="get">
            <input type="text" name="q" placeholder="Buscar conteúdo" />
            <button type="submit">Buscar</button>
        </form>
    </div>
</div>
