<a class="close-open-menu close-menu">

    <img src="<?php echo get_svg('close-open-menu')?>" />

</a>
<a href="http://www.novalehub.com.br">
<picture class="logo">
        <img src="<?php echo get_svg('logo')?>" />
</picture>
</a>
<nav class="menu">
    <ul>
        <?php
        // Obtém o ID do menu 'Principal'
        $menu_principal = wp_get_nav_menu_object('Principal');
        $menu_principal_id = $menu_principal ? $menu_principal->term_id : '';

        // Obtém todos os itens do menu 'Principal'
        $menu_items = wp_get_nav_menu_items($menu_principal_id);

        // Obtém o slug da página atual
        $current_slug = basename(get_permalink());
        $is_blog_active = false;

        // Verifica se a página atual é relacionada ao blog
        if (is_singular('post') || is_category() || is_tag() || is_post_type_archive('post') || is_page('resultado-de-pesquisa')) {
            $is_blog_active = true;
        }

        // Loop para exibir cada item do menu
        if ($menu_items) {
            foreach ($menu_items as $menu_item) {
                // Obtém o slug do item do menu
                $menu_slug = strtolower(trim($menu_item->url, '/'));
                $menu_slug = basename($menu_slug);

                // Verifica se o slug da página atual corresponde ao slug do item do menu
                $is_active = '';

                // Verifica se é a página inicial ou se o item do menu é o blog
                if (is_front_page() && $menu_item->title == "Dashboards") {
                    $is_active = 'active';
                } elseif ($menu_item->url === home_url('/blog/') && $is_blog_active) {
                    $is_active = 'active';
                } elseif ($current_slug === $menu_slug) {
                    $is_active = 'active';
                }

                // Obtém o valor do campo de ícone do ACF para o item do menu
                $icone_menu = get_field('icone_menu', 'menu_item_' . $menu_item->ID);

                // Exibe o ícone e o título do item do menu
                echo '<a href="' . $menu_item->url . '" class="' . $is_active . '">';
                echo '<li>';
                if ($icone_menu) {
                    echo '<img src="' . $icone_menu['url'] . '" alt="' . $menu_item->title . '" />';
                }
                echo '<span>'.$menu_item->title.'</span>';
                echo '</li>';
                echo '</a>';
            }
        } else {
            echo '<li>Nenhum item encontrado no menu.</li>';
        }
        ?>
    </ul>
</nav>


<script>

/**

 * MENU

 */

$(document).ready(function(){

  $(document).on('click', '.close-menu', function(){

    $('.sidenav').addClass('sidenav-small');

    $('.close-menu').addClass('open-menu').removeClass('close-menu');

    $('.sidenav .menu li span').hide();

  });



  $(document).on('click', '.open-menu', function(){

    $('.sidenav').removeClass('sidenav-small');

    $('.open-menu').addClass('close-menu').removeClass('open-menu');

    setTimeout(function() {

    // Sua função aqui

    $('.sidenav .menu li span').fadeIn('slow');

  }, 100); // 2000 milissegundos = 2 segundos

    

  });

  $('.menu-mobile').click(function() {

      $('.sidenav').toggle();

    });

});

</script>

