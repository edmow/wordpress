<?php

$impactData = get_field('impact_data');

$titleImpactData = $impactData['title']; 

?>

<section class="impact-data">

    

    <div class="impact-data-inner">

    <h2><?php echo $titleImpactData?><span>Fonte: <strong><?php echo $impactData['font']?></span></strong></h2> 

        <?php 

        foreach ($impactData['numbers'] as $item):

        ?>

        <div class="box">

            <span class="description"><?php echo $item['description']?></span>

            <span class="number labbo-number" labbo="<?php echo $item['number']?>">0</span>

        </div>

        <?php 

            endforeach;

        ?>

    </div>

</section>