<section class="tab-menu">
    <ul>
        <li class="city city-button active">Ecossistema de Jaraguá do Sul</li>
        <li class="state state-button">Ecossistema de Santa Catarina</li>
    </ul>
</section>