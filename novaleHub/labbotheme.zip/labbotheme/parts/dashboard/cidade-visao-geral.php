<?php
$overview = get_field('overview');
$titleOverview = $overview['title'];
$titleGraphic = $overview['graphic_title'];

$graphics = $overview['graphics'];

$allLines = [];
$uniqueDates = []; 

if ($graphics) {
    foreach ($graphics as $graphic) {
        $color = $graphic['color'];

        $lines = $graphic['line'];

        $lineData = [];
        if ($lines) {
            foreach ($lines as $line) {
                $date = $line['date'];
               
                if (!in_array($date, $uniqueDates)) {
                    $uniqueDates[] = $date;
                }
                $lineData[$date] = [
                    'values' => $line['value'],
                    'color' => $color 
                ];
            }
        }

        $allLines[] = $lineData;
    }
}

sort($uniqueDates);
?>
<section class="overview">
    <h2><?php echo $titleOverview ?><span>Fonte: <strong><?php echo $overview['font']?></strong></span></h2>
    <div class="overview-inner">  
    <div class="left">
        <?php foreach ($overview['numbers'] as $item) : ?>
            <div class="box">
                <img src="<?php echo $item['icon']['url'] ?>">
                <span class="description"><?php echo $item['description'] ?></span>
                <?php
                $number = $item['number'];
                $array = explode('/', $number);
                $first = $array[0];
                $second = $array[1];
                ?>

                <span class="number labbo-number" labbo="<?php echo $first ?>">0</span>
                <span class="number">
                    <?php
                    if ($second) :
                        echo '/';
                    ?>
                </span>
                <span class='number-small labbo-number' labbo="<?php echo $second ?>">0</span>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="right">
         <h3><?php echo $titleGraphic ?></h3>
        <canvas id="graphic-all-companies" class="graphic" style="text-align: center;" width="800" height="300"></canvas>
    </div>
    </div>
</section>
<script>
    var allLines = <?php echo json_encode($allLines); ?>;
    var labels = <?php echo json_encode($uniqueDates); ?>;
    generateGraphicAllCompanies();
</script>

