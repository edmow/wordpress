<?php
$overview = get_field('overview');
$titleOverview = $overview['title'];
$titleGraphic = $overview['graphic_title'];

$graphics = $overview['graphics'];

$allLines = [];
$uniqueDates = []; // Array para armazenar datas únicas

if ($graphics) {
    foreach ($graphics as $graphic) {
        $color = $graphic['color']; // Obtém a cor da linha

        $lines = $graphic['line'];

        $lineData = [];
        if ($lines) {
            foreach ($lines as $line) {
                $date = $line['date'];
                // Verifica se a data já foi adicionada aos rótulos
                if (!in_array($date, $uniqueDates)) {
                    $uniqueDates[] = $date;
                }
                $lineData[$date] = [
                    'values' => $line['value'],
                    'color' => $color // Adiciona a cor da linha aos dados da linha
                ];
            }
        }

        $allLines[] = $lineData;
    }
}

// Ordena as datas únicas
sort($uniqueDates);
?>
<section class="overview">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://unpkg.com/tippy.js@6.3.1/dist/tippy-bundle.umd.min.js"></script>

    <div class="left">
        <h2><?php echo $titleOverview ?></h2>
        <?php foreach ($overview['numbers'] as $item) : ?>
            <div class="box">
                <img src="<?php echo $item['icon']['url'] ?>">
                <span class="description"><?php echo $item['description'] ?></span>
                <?php
                $number = $item['number'];
                $array = explode('/', $number);
                $first = $array[0];
                $second = $array[1];
                if ($second) {
                    $first = $first . '/';
                }
                ?>
                <span class="number"><?php echo $first ?><span class='number-small'><?php echo $second ?></span></span>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="right">
        <h3><?php echo $titleGraphic ?></h3>
        <canvas id="myChart" class="graphic"style="text-align: center;" width="800" height="300"></canvas>
    </div>
</section>
<script>
    var allLines = <?php echo json_encode($allLines); ?>;
    var labels = <?php echo json_encode($uniqueDates); ?>;

    var yearLabels = labels.map(function(date) {
        return date.slice(-4); // Pegar apenas os últimos 4 caracteres (ano) da data
    });

    var datasets = allLines.map(function(lineData) {
        return {
            label: 'Valores',
            data: labels.map(function(date) {
                return lineData[date] ? lineData[date]['values'] : null;
            }),
            borderColor: Object.values(lineData).find(val => val !== null)['color'],
            tension: 0.4
        };
    });


    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels, // Manter os rótulos originais
            datasets: datasets
        },
        options: {
            scales: {
                x: {
                    grid: {
                        display: false // Oculta as linhas verticais do eixo x
                    },
                    ticks: {
                        callback: function(value, index, values) {
                            return yearLabels[index]; // Exibir apenas os últimos 4 caracteres (ano) no eixo x
                        }
                    }
                },
                y: {
                    ticks: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: true,
                    mode: 'nearest',
                    intersect: false,
                    backgroundColor: '#fff',
                    titleFont: {
                        size: 20,
                        weight: '400',
                        family: 'Plus Jakarta Sans',
                    },
                    bodyFont: {
                        size: 28,
                        weight: '700',
                        family: 'Plus Jakarta Sans',
                    },
                    borderWidth: 1,
                    borderColor: '#f0f2f5',
                    displayColors: false,
                    bodyColor: '#000',
                    titleColor: '#667085',
                    callbacks: {
                        label: function(context) {
                            var value = context.dataset.data[context.dataIndex];
                            return formatToReal(value);
                        }
                    }
                }
            }
        }
    });
</script>

