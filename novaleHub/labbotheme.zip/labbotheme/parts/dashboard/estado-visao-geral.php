
<?php
$stateOverview = get_field('state_overview');
$titleStateOverview = $stateOverview['title'];

// Gráficos
$graphicDistribution = $stateOverview['graphic_distribution'];
$graphicCompanies = $stateOverview['graphic_companies'];
$graphicGender = $stateOverview['graphic_gender'];
$graphicAgeRange = $stateOverview['graphic_age_range'];
$graphicProfile = $stateOverview['graphic_profile'];
$graphicEconomic = get_field('economic_data');

?>
<h2><?php echo $titleStateOverview ?><span>Fonte: <strong><?php echo $stateOverview['font']?></span></strong></h2>
<section class="overview">
    <div class="distribution">
        <h3><?php echo $graphicDistribution['title']; ?></h3>
        <div class="graphic-distribution">
    <?php foreach ($graphicDistribution['graphic'] as $item) : 
        $value = $item['value'];
        $number = $item['number'];                
        $progress = intval(($number / ($number + 2000)) * 100);
        ?>
            <div class="item-graphic-distribution">
                <div class="info-graphic-distribution">
                    <span class="region"><?php echo $value; ?></span>
                    <span class="value"><?php echo $number; ?></span>
                </div>
                <div class="line-graphic-distribution">
                    <span style="background:<?php echo $graphicDistribution['color']?>; width: <?php echo $progress?>%;"></span>
                </div>
            </div>
    <?php endforeach; ?>
        </div> 
    </div>
    <div class="companies">
        <h3><?php echo $graphicCompanies['title'] ?></h3>
        <?php
            $valueCompanies = [];
            $numberCompanies = [];
                foreach ($graphicCompanies['Line'] as $item) {
                    $valueCompanies[] = $item['value'];
                    $numberCompanies[] = $item['number'];
                }
            
        ?>
        <canvas id="graphic-companies" height="120"></canvas>
    </div>
    <div class="gender">
        <?php
            $valueGender = [];
            $numberGender = [];
            $colorGender = [];
                foreach ($graphicGender['Line'] as $item) {
                    $valueGender[] = $item['value'];
                    $numberGender[] = $item['number'];
                    $colorGender[] = $item['color'];
                }
            
        ?>
        <h3><?php echo $graphicGender['title']; ?></h3>
        <canvas id="graphic-gender"></canvas>
    </div>
    
    <div class="age-range">
    <h3><?php echo $graphicAgeRange['title']; ?></h3>
    <?php
        foreach ($graphicAgeRange['Line'] as $item):
            $width = 100 - $item['number-one'];
    ?>

    <div class="age-range-inner">
        <div class="age-range-item">
            <div class="region"><?php echo $item['value']?></div>
            <div style="background: <?php echo $graphicAgeRange['color-two']?>" class="graphic">
                <span  data-value="<?php echo $item['number-one']?>%" class="age-range-first" style="width: <?php echo $item['number-one']?>%; background: <?php echo $graphicAgeRange['color-one']?>"><?php echo $item['number-one']?>%</span>
                <span  data-value="<?php echo $item['number-second']?>%" class="age-range-second" style="color: #7E2410; padding-right: 150px"><?php echo $item['number-two']?>%</span>
            </div>
            <div class="legend"><?php echo $item['legend']?></div>
        </div>
    </div>
    <?php
        endforeach;                
    ?>
    <div class="age-range-legend">
    <span style="background:<?php echo $graphicAgeRange['color-one']?>"></span>Mulheres
    <span style="background:<?php echo $graphicAgeRange['color-two']?>"></span>Homens
    </div>
    </div>
    
    <div class="profile">
    <?php
            $valueProfile= [];
            $numberProfile = [];
            $colorProfile = [];
                foreach ($graphicProfile['Line'] as $item) {
                    $valueProfile[] = $item['value'];
                    $numberProfile[] = $item['number'];
                    $colorProfile[] = $item['color'];
                }
            
        ?>
        <h3><?php echo $graphicProfile['title']; ?></h3>
        <canvas id="graphic-profile"></canvas>
    </div>
</section> 
<section class="economic-data">
    <h2><?php echo $graphicEconomic['title']?><span>Fonte: <strong><?php echo $graphicEconomic['font']?></strong></span></h2>
    <div class="economic-data-inner">
    <?php 
        foreach ($graphicEconomic['numbers'] as $item):
    ?>
        <div class="box">
            <span class="description"><?php echo $item['description']?></span>
            <span class="value"><?php echo $item['value']?></span>
        </div>
    <?php
        endforeach;
    ?>
    </div>
</section>
<script>
    //Grafico -> Número de empresas de Tecnologia em Santa Catarina
    var datesCompanies = <?php echo json_encode($valueCompanies); ?>;
    var valuesCompanies = <?php echo json_encode($numberCompanies); ?>;
    var color = <?php echo json_encode($graphicCompanies['color'] ); ?>;
    generateGraphicDistribution();

    //Grafico -> Gênero dos empreendedores
    var valueGender = <?php echo json_encode($valueGender); ?>;
    var numberGender = <?php echo json_encode($numberGender); ?>;
    var colorGender = <?php echo json_encode($colorGender); ?>;
    generateGraphicGender();
        

    //Grafico -> Perfil dos Desenvolvedores
    var valueProfile = <?php echo json_encode($valueProfile); ?>;
    var numberProfile = <?php echo json_encode($numberProfile); ?>;
    var colorProfile = <?php echo json_encode($colorProfile); ?>;
    generateGraphicProfile();
</script>
