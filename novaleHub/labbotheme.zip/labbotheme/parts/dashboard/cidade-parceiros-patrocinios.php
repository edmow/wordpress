<?php

$partners = get_field('partners');

$titlePartners= $partners['title']; 

?>

<section class="partners">

    

    <div class="partners-inner">

    <h2><?php echo $titlePartners?><span>Fonte: <strong><?php echo $partners['font']?></span></strong></h2>

        <?php 

        foreach ($partners['numbers'] as $item):

        ?>

        <div class="box">

            <img src="<?php echo $item['icon']['url']?>">

            <span class="description"><?php echo $item['description']?></span>

            <span class="number labbo-number" labbo="<?php echo $item['number']?>">0</span>

        </div>

        <?php 

            endforeach;

        ?>

    </div>

</section>