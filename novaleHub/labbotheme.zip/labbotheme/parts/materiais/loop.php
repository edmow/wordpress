<?php

$current_category = get_queried_object();
$current_category_slug = "";
$current_category_slug = $current_category->slug;
$categories = get_terms(array(
    'taxonomy' => 'materiais',
    'hide_empty' => false,
));

$posts_per_page = 5; // Definindo a quantidade de posts por página

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1; // Obtendo o número da página atual

$args = array(
    'post_type' => 'material',
    'posts_per_page' => $posts_per_page,
    'paged' => $paged, // Configurando a página atual
    'post_status' => 'publish', // Apenas posts publicados
    
);


if ($current_category_slug) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => 'materiais',
            'field' => 'slug',
            'terms' => $current_category_slug
        )
    );
}
$material_posts = new WP_Query($args);
if ($material_posts->have_posts()) :
?>
    <section class="materials">
        <?php if (!empty($categories)) : ?>
            <div class="categories">
                <span class="category-title">Categorias de materiais</span>
                <ul>
                    <?php foreach ($categories as $category) : ?>
                        <?php
                        $post_count = $category->count;
                        ?>
                        <li>
                            <a href="<?php echo esc_url(get_term_link($category)); ?>">
                                <?php echo esc_html($category->name); ?>
                                <span><?php echo $post_count; ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php 
            if ($material_posts->have_posts()) : ?>
            <div class="loop">
                <div class="loop-inner">
                        <div class="loop-header">
                            <div class="item-name"><span>Nome do Material</span></div>
                            <div class="item-category"><span>Categoria</span></div>
                            <div class="item-format"><span>Formato</span></div>
                            <div class="item-size"><span>Tamanho</span></div>
                        </div>
                        <div class="loop-body">
                            <?php while ($material_posts->have_posts()) : $material_posts->the_post(); ?>
                                <div class="loop-item">
                                    <div class="item-name"><?php the_title(); ?></div>
                                    <div class="item-category">
                                        <?php
                                        $categories = get_the_terms(get_the_ID(), 'materiais');
                                        if ($categories && !is_wp_error($categories)) {
                                            $category_names = array();
                                            foreach ($categories as $category) {
                                                $category_names[] = $category->name;
                                            }
                                            echo esc_html(implode(', ', $category_names));
                                        }
                                        ?>
                                    </div>
                                    <?php
                                    $material_format = get_field('material_format'); // Definindo $material_format para cada post
                                    ?>
                                    <div class="item-format">
                                        <?php
                                        echo ($material_format === 'arquivo') ? pathinfo(get_field('file')['url'], PATHINFO_EXTENSION) : 'Online';
                                        ?>
                                    </div>
                                    <div class="item-size">
                                        <?php
                                        if ($material_format === 'arquivo') {
                                            $file_url = get_field('file')['url'];
                                            $file_path = parse_url($file_url)['path'];
                                            $file_size = filesize($_SERVER['DOCUMENT_ROOT'] . $file_path);
                                            echo size_format($file_size, 2);
                                        } else {
                                            echo 'N/A';
                                        }
                                        ?>
                                    </div>
                                    <div class="item-action">
                                        <?php
                                        if ($material_format === 'arquivo') {
                                            $file = get_field('file');
                                            if (!empty($file)) {
                                                echo '<a href="' . esc_url($file['url']) . '">Baixar material <img src="'.get_svg("icon-download").'" alt=""></a>';
                                            }
                                        } elseif ($material_format === 'online') {
                                            $url_material = get_field('url_material');
                                            if (!empty($url_material)) {
                                                echo '<a href="' . esc_url($url_material) . '">Acessar <img src="'.get_svg("icon-acess").'" alt=""></a>';
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                </div>
                <div class="paginacao">
                    <?php 
                    // Paginação
                    $next = "<img class='pagination-next' src='" . get_svg('arrow-right') . "' alt='->'>";
                    $prev = "<img style='transform: rotate(-180deg);' class='pagination-prev' src='" . get_svg('arrow-right') . "' alt='<-'>";
                
                    if (function_exists('wordpress_pagination')) {
                        echo paginate_links(array(
                            'total' => $material_posts->max_num_pages, // Total de páginas
                            'current' => max(1, $paged), // Página atual
                            'prev_text' => __($prev),
                            'next_text' => __( $next),
                        ));
                    }
                    ?>
                </div>
            </div>
        <?php endif; ?>

    </section> <!-- Fechamento da seção 'materials' -->
<?php endif;

wp_reset_postdata();
?>
