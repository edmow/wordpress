<?php 

$tituloTour = get_field('titulo_tour');
$textoTuor = get_field('texto_tour');
$videoTuor = get_field('video_tour');

?>


<section>

    <div class="content-tuor">
        <div>
            <h2><?php echo $tituloTour?></h2>
            <p><?php echo $textoTuor?></p>
        </div>
        <div>
            <?php echo $videoTuor ?>
        </div>
    </div>

</section>