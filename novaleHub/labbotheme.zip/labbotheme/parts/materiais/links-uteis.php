<?php

$useful_links = get_field('useful_links', 440);

$title = get_field('title_useful_links', 440);

$description = get_field('description_useful_links', 440);



?>

<section class="useful-links">

    <!-- <div style="margin-top: 50px; border-radius: 10px; overflow: hidden;">

        <div class="container-wrapper-genially" style="position: relative; min-height: 400px; maxwidth: 100%;"><img src="https://img.genial.ly/6298ad54b7720d0011edd66e/0dc89e4da98a-42ce-a12c-a93a4c945af2.png" class="loader-genially" style="position: absolute; top:

0; right: 0; bottom: 0; left: 0; margin-top: auto; margin-right: auto; margin-bottom: auto; margin-left: auto; z-index: 1;width: 80px; height: 80px;" />
            <div id="64b9190ae0ceb10011f749b6" class="genially-embed" style="margin: 0px auto; position: relative; height: auto; width: 100%;"></div>
        </div>
        <script>
            (function(d) {
                var js, id = "genially-embed-js",
                    ref = d.getElementsByTagName("script")[0];
                if (d.getElementById(id)) {
                    return;
                }
                js = d.createElement("script");
                js.id = id;
                js.async = true;
                js.src =

                    "https://view.genial.ly/static/embed/embed.js";
                ref.parentNode.insertBefore(js, ref);
            }(document));
        </script>

    </div> -->

    <div class="useful-links-inner">

        <div class="useful-links-header">

            <h2><?php echo $title; ?></h2>

            <p><?php echo $description; ?></p>





        </div>

        <?php foreach ($useful_links as $link) : ?>

            <a href="<?php echo $link['item']['url']; ?>" target="_blank" class="useful-link">

                <?php echo $link['item']['title']; ?>

                <img src="<?php echo get_svg("icon-acess") ?>">

            </a>

        <?php endforeach; ?>

    </div>

</section>