<?php

    $entrepreneurial = get_field('entrepreneurial',440);
    
?>

<section class="entrepreneurial">

    <div class="left">

        <figure>

            <img class="featured" src="<?php echo $entrepreneurial['image']['url'];?>">

            <img class="floating" src="<?php echo $entrepreneurial['image_png']['url'];?>">

            

        </figure>

    </div>

    <div class="right">

        <span><?php echo $entrepreneurial['subtitle'];?></span>

        <h2><?php echo $entrepreneurial['title'];?></h2>

        <p><?php echo nl2br($entrepreneurial['description'])?></p>

        <a href="<?php echo $entrepreneurial['link']['url'];?>" target="_blank"><?php echo $entrepreneurial['link']['title'];?><img src="<?php echo get_svg("icon-download")?>"></a>

    </div>

</section>