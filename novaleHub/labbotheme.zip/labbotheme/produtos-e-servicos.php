<?php
/*
Template Name: Produtos e Serviços
*/
?>
<?php get_header();
$bannerCall = get_field('product_banner_call');
$bannerTitle = get_field('product_banner_title');
$bannerText = get_field('product_banner_text');
$bannerBackground = get_field('product_banner_img');
$notFindText = get_field('text_not_find');
$notFindLink = get_field('link_not_find'); 
?>
<?php get_template_part('parts/btn-whatsapp/whatsapp') ?>
<div class="products-services">
    <div class="banner" style="background:url(<?php echo $bannerBackground ?>)">
        <span><?php echo $bannerCall ?></span>
        <h1><?php echo $bannerTitle ?></h1>
        <p><?php echo $bannerText ?></p>
    </div>
    <div class="loop-products">
        <?php
        $uri_paged = $_SERVER['REQUEST_URI'];
        $uri_paged = explode('/', $uri_paged);
        $uri_paged = $uri_paged[count($uri_paged) - 2];
        $paged = (!$uri_paged) ? 1 : $uri_paged;
        $paged = (int) $paged;
        $args = array(
            'post_type'         => 'produtos',
            'nopaging'          => false,
            'paged'             => $paged,
            'posts_per_page'    => '6',
            'order' => 'asc'
        );
        $the_query = new WP_Query($args);
        global $wp_query;
        // Put default query object in a temp variable
        $tmp_query = $wp_query;
        // Now wipe it out completely
        $wp_query = null;
        // Re-populate the global with our custom query
        $wp_query = $the_query;
        if ($the_query->have_posts()) :
            $count = 0;
            while ($the_query->have_posts()) : $the_query->the_post();
                $count++;
                $whatsapp = "https://api.whatsapp.com/send?phone=554733075374&text=Olá! Gostaria de saber mais sobre: ".get_the_title();
                echo '<div class="card-produto">';
                echo '<a href="' . $whatsapp . '">';
                echo '<figure>';
                if (has_post_thumbnail()) {
                    echo get_the_post_thumbnail();
                } else {
                    echo '<img class="default-img" src="' . get_svg('default') . '" alt="" />';
                }
                echo '</figure>';
                echo '</a>';
                echo '<h3 class="card-title">' . get_the_title() . '</h3>';
                echo '<div class="description">';
                echo get_the_content();
                echo '</div>';
                echo '<a href="' . $whatsapp . '" target="_blank" class="button">Saiba mais <img class="default-img" src="' . get_svg('export') . '" alt="" /></a>';
                echo '</div>';
                // Adicionar hr após 3 itens
                if ($count % 3 == 0 && $count < 6) {
                    echo '<hr>';
                }
            endwhile;
        ?>
            <div class="paginacao">
                <?php wordpress_pagination(); ?>
            </div>
        <?php
            // Restaurar os dados originais do post
            wp_reset_postdata();
        else :
            // Caso não haja posts
            echo 'Nenhum post encontrado.';
        endif;
        ?>
    </div>
    <div class="not-find">
        <span><?php echo nl2br($notFindText)?></span>
        <a target="<?php echo $notFindLink['target']?>" href="<?php echo $notFindLink['url']?>"><?php echo $notFindLink['title']?><img src="<?php echo get_svg('export')?>"></a>
    </div>
</div>
<?php get_footer(); ?>