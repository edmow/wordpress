<?php get_header(); ?>
<div class="content">
        <?php get_template_part('parts/blog/filter'); ?>
        
    <article>
        <?php get_template_part('parts/blog/single/banner-feature'); ?>
        <?php get_template_part('parts/blog/single/content'); ?>
        <?php get_template_part('parts/blog/single/loop'); ?>
    </article>
</div>
<?php get_footer(); ?>