
<?php get_header(); ?>
<div class="content">
    <?php get_template_part('parts/blog/filter'); ?>
    <?php get_template_part('parts/blog/category/banner-feature'); ?>
    <?php get_template_part('parts/blog/category/loop'); ?>
    <?php get_template_part('parts/blog/newsletter'); ?>
</div>
<?php get_footer(); ?>