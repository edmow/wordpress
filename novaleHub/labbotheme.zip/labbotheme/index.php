<?php

/*

Template Name: Dashboard

*/

?>



<?php get_header(); ?>
    

  <div class="content">

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://unpkg.com/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

    <script src="https://unpkg.com/tippy.js@6.3.1/dist/tippy-bundle.umd.min.js"></script>

    <div class="content-inner">

      <?php

        get_template_part('parts/dashboard/menu-abas');

      ?>

      <div class="city-data active">

        <?php

          get_template_part('parts/dashboard/cidade-visao-geral');

          get_template_part('parts/dashboard/cidade-dados-impacto');

          get_template_part('parts/dashboard/cidade-parceiros-patrocinios');

        ?>

      </div>

      <div class="state-data ">

        <?php

          get_template_part('parts/dashboard/estado-visao-geral');

        ?>

      </div>

    </div>

  </div>

  <?php get_template_part('parts/btn-whatsapp/whatsapp') ?>
<?php get_footer(); ?>