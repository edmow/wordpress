<?php
/*
Template Name: Política de privacidade
*/
?>

<?php get_header(); ?>

<div class="privacy-policy">
    <div class="container">
        <?php the_content(); ?>
    </div>
</div>

<?php get_footer(); ?>