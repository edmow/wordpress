<?php
/*
Template Name: Quem somos
*/
?>
<?php get_header();
// Controle de seções
$mostrar_sobre = get_field('quem_somos_sobre');
$mostrar_destaques = get_field('quem_somos_destaques');
$mostrar_ecossistema = get_field('quem_somos_ecossistema');
$mostrar_apoiadores = get_field('quem_somos_apoiadores');

// Sobre
$titulo_sobre = get_field('titulo_sobre');
$title_color_portal = get_field('title_color_portal');
$pilares_sobre = get_field('pilares');
// Portal
$chamada_portal = get_field('chamada_portal');
$cor_chamada_portal = get_field('cor_chamada_portal');
$titulo_portal = get_field('titulo_portal');
$texto_portal = get_field('texto_portal');
$imagem_portal =get_field('imagem_portal');
$bg_color_portal_1 = get_field('bg_color_portal_1');
$bg_color_portal_2 = get_field('bg_color_portal_2');
// Beneficios
$titulo_sobre_beneficios = get_field('titulo_beneficios');
$texto_sobre_beneficios = get_field('texto_beneficios');
$beneficios = get_field('beneficios_quem_somos');
// Destaque
$destaques = get_field('destaques');
// Ecossistema
$titulo_ecossistema = get_field('titulo_ecossistema');
$ecossistema = get_field('ecossistema');
//Parceiros
$image_partners = get_field('image_partners');
$gallery_partners = get_field('galeria_parceiros');
// Apoiadores
$titulo_apoiadores = get_field('titulo_apoiadores');
$fundadores = get_field('fundadores');
$mantenedores = get_field('mantenedores');
$parceiros = get_field('parceiro_slide');

// Clientes
$clients_show = get_field('clients_show');
$clients = get_field('clients');
$titleClients= $clients['title'];

// Banner principal
$banner_featured_show = get_field('banner_featured_show'); 
$banner_featured = get_field('banner_featured'); 
?>

<?php get_template_part('parts/btn-whatsapp/whatsapp') ?>
<div class="we-are-container">
    <?php if($banner_featured_show && $banner_featured):?>
    <div class="owl-featured-banner owl-carousel owl-theme">
        <?php foreach ($banner_featured as $item) {
            // Acessar os subcampos usando o formato solicitado
            $featured_banner_title = $item['title'];
            $featured_banner_text = $item['text'];
            $featured_banner_image = $item['image_desktop'];
            $featured_banner_image_mobile = $item['image_mobile'];
            $featured_banner_link = $item['link'];
            $featured_banner_inserir_protecao_texto_fundo = $item['inserir_protecao_texto_fundo'];
            ?>

            <div class="featured-banner">
                <picture>
                    <source media="(max-width: 991px)" srcset="<?php echo esc_url($featured_banner_image_mobile['url']); ?>">
                    <img src="<?php echo $featured_banner_image['url']?>">
                </picture>
                
                <div class="featured-banner-inner<?php if ( $featured_banner_inserir_protecao_texto_fundo ) { echo ' protecao-texto'; } ?>">
                    <div>
                        <?php if ( $featured_banner_title ): ?>
                            <h1><?php echo $featured_banner_title;?></h1>
                        <?php endif ?>

                        <?php if ( $featured_banner_text ): ?>
                            <p><?php echo $featured_banner_text;?></p>
                        <?php endif ?>
                        
                        <?php if ( $featured_banner_link ): ?>
                            <a href="<?php echo $featured_banner_link['url']?>" target="<?php echo $featured_banner_link['target']?>">
                                <?php echo $featured_banner_link['title']?>
                            </a>
                        <?php endif ?>
                    </div>
                </div>
            </div>

            <?php
        } ?>
    </div>
    <?php endif;?>

    <div class="padding-70" style="padding:70px;">
        <div class="owl-banner owl-carousel owl-theme">
            <?php
            // Recuperar o campo repetidor
            $repeater_banner = get_field('repeater_banner'); 

            if ($repeater_banner) {
                foreach ($repeater_banner as $item) {
                    // Acessar os subcampos usando o formato solicitado
                    $bg_color_banner_1 = $item['bg_color_1'];
                    $bg_color_banner_2 = $item['bg_color_2'];
                    $subtitle_color_banner = $item['subtitle_color'];
                    $subtitle = $item['subtitle'];
                    $title_color_banner = $item['title_color'];
                    $title = $item['title'];
                    $text = $item['text'];
                    $image = $item['image'];
                    $link = $item['link'];
                    $cor_do_texto_do_botao = $item['cor_do_texto_do_botao'];
                    $cor_de_fundo_do_botao = $item['cor_de_fundo_do_botao'];
                    ?>

                    <div class="banner" style="background-image: linear-gradient(to bottom, <?php echo esc_attr($bg_color_banner_1); ?>, <?php echo esc_attr($bg_color_banner_2); ?>);">
                        <div class="left">
                            <span style="color:<?php echo esc_attr($subtitle_color_banner); ?>"><?php echo esc_html($subtitle); ?></span>
                            <h1 style="color:<?php echo esc_attr($title_color_banner); ?>"><?php echo esc_html($title); ?></h1>
                            <div class="description"><?php echo $text; ?></div>
                            <?php if( $link ):?>
                                <a href="<?php echo $link['url'];?>" target="<?php echo $link['target'];?>" style="color: <?php echo $cor_do_texto_do_botao; ?>; background-color: <?php echo $cor_de_fundo_do_botao; ?>; border: 1px solid <?php echo $cor_de_fundo_do_botao; ?>">
                                    <?php echo $link['title'];?>
                                </a>

                                <style type="text/css">
                                    .we-are-container .banner .left a:hover{
                                      color: <?php echo $cor_de_fundo_do_botao; ?> !important;
                                      background-color: <?php echo $cor_do_texto_do_botao; ?> !important;
                                    }
                                </style>
                            <?php endif;?>
                        </div>
                        <div class="right">
                            <figure>
                                <img width="auto" height="auto" src="<?php echo $image['url']; ?>" alt="Imagem do Carrossel" rel="preload" loading="lazy">
                            </figure>
                        </div>
                    </div>

                    <?php
                }
            }
            ?>
        </div>
        <div class="portal">
            <div class="portal-inner" style="background-image: linear-gradient(to bottom, <?php echo $bg_color_portal_1?>, <?php echo $bg_color_portal_2?>);">
                <div class="portal-image">           
                    <img rel="preload" src="<?php echo $imagem_portal?>" alt="novalehub" fetchpriority="low">
                </div>
                <div class="portal-title">
                    <h5 style="color:<?php echo $cor_chamada_portal?>"><?php echo $chamada_portal ?></h5>
                    <h4 style="color:<?php echo $title_color_portal?>"><?php echo $titulo_portal ?></h4>
                    <p><?php echo $texto_portal ?></p> 
                </div>
            </div>
        </div>
        <?php if ($mostrar_sobre) : ?>
            <div class="about">
                <h4><?php echo $titulo_sobre ?></h4>
                <div class="pilars">
                    <?php foreach ($pilares_sobre as $pilar_key => $pilar) : ?>
                        <div class="pilar">
                            <?php if (isset($pilar['icone'])) : ?>
                                <img src="<?php echo $pilar['icone']; ?>" alt="Ícone do Pilar">
                            <?php endif; ?>
                            <div class="content-pilar">
                                <?php if (isset($pilar['titulo'])) : ?>
                                    <h5><?php echo $pilar['titulo']; ?></h5>
                                <?php endif; ?>
                                <?php if (isset($pilar['texto'])) : ?>
                                    <p><?php echo $pilar['texto']; ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="benefects">
                <div class="benefects-title">
                    <h4><?php echo $titulo_sobre_beneficios ?></h4>
                    <p><?php echo $texto_sobre_beneficios ?></p>
                </div>
                <div class="benefects-content">
                    <?php foreach ($beneficios as $benefect_key => $benefect) : ?>
                        <?php if (isset($benefect['beneficio'])) : ?>
                            <?php $beneficio = $benefect['beneficio']; ?>
                            <div class="benefect">
                                <?php if (!empty($beneficio['icone'])) : ?>
                                    <img src="<?php echo esc_url($beneficio['icone']); ?>" alt="Ícone do Benefect">
                                <?php endif; ?>
                                <div class="content-benefect">
                                    <?php if (!empty($beneficio['titulo'])) : ?>
                                        <h5><?php echo esc_html($beneficio['titulo']); ?></h5>
                                    <?php endif; ?>
                                    <?php if (!empty($beneficio['texto'])) : ?>
                                        <p><?php echo esc_html($beneficio['texto']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php if ($mostrar_destaques) : ?>
            <div class="spotlights">
                <?php foreach ($destaques as $index => $destaque) : ?>
                    <?php if (isset($destaque['destaque'])) : ?>
                        <?php $info_destaque = $destaque['destaque']; ?>
                        <div class="spotlight">
                            <div class="numero"><?php echo $index + 1; ?></div>
                            <div class="conteudo-destaque">
                                <?php if (!empty($info_destaque['titulo'])) : ?>
                                    <h5><?php echo esc_html($info_destaque['titulo']); ?></h5>
                                <?php endif; ?>
                                <?php if (!empty($info_destaque['imagem'])) : ?>
                                    <img src="<?php echo esc_url($info_destaque['imagem']); ?>" alt="<?php echo esc_attr($info_destaque['titulo']); ?>">
                                <?php endif; ?>
                                <?php if (!empty($info_destaque['texto'])) : ?>
                                    <p><?php echo esc_html($info_destaque['texto']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if (false) : ?>
            <div class="partners">
                <h2><?php echo $titulo_ecossistema ?></h2>
                <div class="all-setors">
                    <?php
                    $contador = 0; // Inicializa o contador
                    foreach ($ecossistema as $setor) :
                        if (isset($setor['setor'])) :
                            $info_setor = $setor['setor'];
                    ?>
                            <div class="setor">
                                <?php if (!empty($info_setor['titulo'])) : ?>
                                    <h5><?php echo esc_html($info_setor['titulo']); ?></h5>
                                <?php endif; ?>
                                <?php if (!empty($info_setor['imagem'])) : ?>
                                    <img src="<?php echo esc_url($info_setor['imagem']); ?>" alt="<?php echo esc_attr($info_setor['titulo']); ?>">
                                <?php endif; ?>
                            </div>
                            <?php
                            // Exibe o divisor após o primeiro, segundo e quarto item
                            if ($contador == 0 || $contador == 1 || $contador == 3) {
                                echo '<div class="divider-setor"></div>';
                            }
                            $contador++; // Incrementa o contador
                            ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php if ($mostrar_ecossistema) : ?>
            <div class="partners">
                <h2><?php echo $titulo_ecossistema ?></h2>
                <div class="all-setors">
                <!-- <img src="<?php echo $image_partners['url']; ?>" alt="<?php echo $titulo_ecossistema; ?>"> -->
                    <?php if( $gallery_partners ): ?>
                        <?php foreach( $gallery_partners as $image ): ?>
                            <div>
                                <img src="<?php echo esc_url($image); ?>" alt="logo parceiros">
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php if ($mostrar_apoiadores) : ?>
            <div class="supporters">
                <h2><?php echo $titulo_apoiadores ?></h2>
                <div class="sliders-sup">
                    <h4><?php echo $fundadores['titulo'] ?></h4>
                    <?php if (isset($fundadores['logo']) && is_array($fundadores['logo']) && count($fundadores['logo']) > 0) : ?>
                        <div class="owl-fundadores owl-carousel owl-theme">
                            <?php foreach ($fundadores['logo'] as $logo) : ?>
                                <?php if (isset($logo['logo']) && is_numeric($logo['logo'])) : ?>
                                    <?php
                                    $logo_fundadores = wp_get_attachment_url($logo['logo']);
                                    if ($logo_fundadores) : ?>
                                        <div class="item"><img src="<?php echo $logo_fundadores; ?>" alt="Logo"></div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                        <div class="divider-slide"></div>
                    <?php endif; ?>
                    <h4><?php echo $mantenedores['titulo'] ?></h4>
                    <?php if (isset($mantenedores['logo']) && is_array($mantenedores['logo']) && count($mantenedores['logo']) > 0) : ?>
                        <div class="owl-mantenedores owl-carousel owl-theme">
                            <?php foreach ($mantenedores['logo'] as $logo) : ?>
                                <?php if (isset($logo['logo']) && is_numeric($logo['logo'])) : ?>
                                    <?php
                                    $logo_mantenedores = wp_get_attachment_url($logo['logo']);
                                    if ($logo_mantenedores) : ?>
                                        <div class="item"><img src="<?php echo $logo_mantenedores; ?>" alt="Logo"></div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                        <div class="divider-slide"></div>
                    <?php endif; ?>
                    <h4><?php echo $parceiros['titulo'] ?></h4>
                    <?php if (isset($parceiros['logo']) && is_array($parceiros['logo']) && count($parceiros['logo']) > 0) : ?>
                        <div class="owl-parceiros owl-carousel owl-theme">
                            <?php foreach ($parceiros as $parceiro) : ?>
                                <?php
                                $logo_parceiros = wp_get_attachment_url($logo['logo']);
                                if ($logo_parceiros) : ?>
                                    <div class="item"><img src="<?php echo $logo_parceiros; ?>" alt="Logo"></div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php if ($clients_show) : ?>
        <section class="clients">
            <h2><?php echo $titleClients?></h2>
            <div class="clients-inner owl-clients owl-carousel owl-theme">
                <?php 
                foreach ($clients['items'] as $item):
                ?>
                <div class="box">
                    <img src="<?php echo $item['image']['url']?>">
                </div>
                <?php 
                    endforeach;
                ?>
            </div> 
        </section>
        <?php endif; ?>
    </div>
</div>
<?php get_footer(); ?>
<script>
    $(document).ready(function() {
        $('.owl-featured-banner').each(function() {
            var $this = $(this);
            var itemCount = $this.find('.owl-item').length;

            $this.owlCarousel({
                nav: true,
                dots: false,
                items: 1,
                loop: itemCount > 1,
                autoplay: itemCount > 1,
                slideTransition: 'linear',
                autoplayTimeout: 6000,
                autoplayHoverPause: itemCount > 1,
                navText: ['<img style="transform: rotate(180deg);" src="/wp-content/themes/labbotheme/assets/svg/arrow-right.svg">', '<img src="/wp-content/themes/labbotheme/assets/svg/arrow-right.svg">']
            });
        });

        $('.owl-banner').each(function() {
            var $this = $(this);
            var itemCount = $this.find('.owl-item').length;

            $this.owlCarousel({
                nav: true,
                dots: false,
                items: 1,
                loop: itemCount > 1,
                autoplay: itemCount > 1,
                slideTransition: 'linear',
                autoplayTimeout: 6000,
                autoplayHoverPause: itemCount > 1,
                navText: ['<img style="transform: rotate(180deg);" src="/wp-content/themes/labbotheme/assets/svg/arrow-right.svg">', '<img src="/wp-content/themes/labbotheme/assets/svg/arrow-right.svg">']
            });
        });

        $('.galeria-banner').owlCarousel({
            nav: false,
            dots: false,
            items: 1,
            loop: false,
            navText: ['<img style="transform: rotate(180deg);" src="/wp-content/themes/labbotheme/assets/svg/arrow-right.svg">', '<img src="/wp-content/themes/labbotheme/assets/svg/arrow-right.svg">']
        })
        $('.owl-fundadores').owlCarousel({
            loop: true,
            margin: 30,
            nav: false,
            dots: false,
            autoplay: true,
            slideTransition: 'linear',
            autoplayTimeout: 6000,
            autoplaySpeed: 6000,
            autoplayHoverPause: false,
            responsive: {
                0: {
                    items: 2,
                },
                768: {
                    items: 3,
                },
                991: {
                    items: 3,
                },
                1000: {
                    items: 6,
                }
            }
        })
        $('.owl-mantenedores').owlCarousel({
            loop: true,
            margin: 30,
            nav: false,
            dots: false,
            autoplay: true,
            slideTransition: 'linear',
            autoplayTimeout: 6000,
            autoplaySpeed: 6000,
            autoplayHoverPause: false,
            responsive: {
                0: {
                    items: 2,
                },
                768: {
                    items: 3,
                },
                991: {
                    items: 3,
                },
                1000: {
                    items: 6,
                }
            }
        })
        $('.owl-parceiros').owlCarousel({
            loop: true,
            margin: 30,
            nav: false,
            dots: false,
            autoplay: true,
            slideTransition: 'linear',
            autoplayTimeout: 6000,
            autoplaySpeed: 6000,
            autoplayHoverPause: false,
            responsive: {
                0: {
                    items: 2,
                },
                768: {
                    items: 3,
                },
                991: {
                    items: 3,
                },
                1000: {
                    items: 6,
                }
            }
        })
        $('.owl-clients').owlCarousel({
            loop: true,
            margin: 30,
            nav: false,
            dots: true,
            responsive: {
                0: {
                    items: 2,
                },
                768: {
                    items: 3,
                },
                1000: {
                    items: 4,
                }
            }
        })
    });
</script>