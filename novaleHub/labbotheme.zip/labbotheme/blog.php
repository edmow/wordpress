<?php
/*
Template Name: Blog
*/
?>
<?php get_header(); ?>
<div class="content">
    <?php get_template_part('parts/blog/filter'); ?>
    <?php get_template_part('parts/blog/banner-feature'); ?>
    <?php get_template_part('parts/blog/loop'); ?>
    <?php get_template_part('parts/blog/newsletter'); ?>
</div>
<?php get_footer(); ?>