<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width">
<meta name="description" content="<?= get_bloginfo(); ?>" />
<meta name="theme-color" content="#339CF7">
<title><?php bloginfo('name'); ?> <?php is_front_page() ? bloginfo('description') : wp_title(); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<?php wp_head(); ?>
</head>
<body>
	<div class="grid-container">
		<header class="header">
			<div class="list-coin">
			<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "description": "",
      "proName": "BMFBOVESPA:VALE3"
    },
    {
      "description": "",
      "proName": "BMFBOVESPA:CIEL3"
    },
    {
      "description": "",
      "proName": "BMFBOVESPA:VAMO3"
    },
    {
      "description": "",
      "proName": "BMFBOVESPA:BHIA3"
    },
    {
      "description": "",
      "proName": "BMFBOVESPA:CRFB3"
    },
    {
      "description": "",
      "proName": "BMFBOVESPA:MGLU3"
    },
    {
      "description": "",
      "proName": "BITSTAMP:BTCUSD"
    },
    {
      "description": "",
      "proName": "BINANCE:ETHUSD"
    },
    {
      "description": "",
      "proName": "BINANCE:BTCUSDT"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "light",
  "isTransparent": false,
  "displayMode": "compact",
  "locale": "br"
}
  </script>
</div>
<!-- TradingView Widget END -->
			</div>
      <a class="logo-mobile" href="http://www.novalehub.com.br">
        <picture class="logo">
                <img src="<?php echo get_svg('logo')?>" />
        </picture>
      </a>
    <div class="menu-mobile">
    <div id="burguer-menu" class="burguer" onclick="this.classList.toggle('active')">
      <svg xmlns="http://www.w3.org/2000/svg" width="90" height="90" viewBox="0 0 200 200">
            <g stroke-width="6.5" stroke-linecap="round">
              <path
                d="M72 82.286h28.75"
                fill="#009100"
                fill-rule="evenodd"
                stroke="#fff"
              />
              <path
                d="M100.75 103.714l72.482-.143c.043 39.398-32.284 71.434-72.16 71.434-39.878 0-72.204-32.036-72.204-71.554"
                fill="none"
                stroke="#fff"
              />
              <path
                d="M72 125.143h28.75"
                fill="#009100"
                fill-rule="evenodd"
                stroke="#fff"
              />
              <path
                d="M100.75 103.714l-71.908-.143c.026-39.638 32.352-71.674 72.23-71.674 39.876 0 72.203 32.036 72.203 71.554"
                fill="none"
                stroke="#fff"
              />
              <path
                d="M100.75 82.286h28.75"
                fill="#009100"
                fill-rule="evenodd"
                stroke="#fff"
              />
              <path
                d="M100.75 125.143h28.75"
                fill="#009100"
                fill-rule="evenodd"
                stroke="#fff"
              />
            </g>
          </svg>
    </div>
    <style>
      .burguer {
        cursor: pointer;
        display: flex;
      }
      .burguer svg {
        transition: transform 500ms cubic-bezier(0.4, 0, 0.2, 1);
      }
      .burguer.active svg {
        transform: rotate(90deg);
      }
      .burguer path {
        transition: transform 500ms cubic-bezier(0.4, 0, 0.2, 1),
          stroke-dasharray 500ms cubic-bezier(0.4, 0, 0.2, 1),
          stroke-dashoffset 500ms cubic-bezier(0.4, 0, 0.2, 1);
      }
      .burguer path:nth-child(1) {
        transform-origin: 36% 40%;
      }
      .burguer path:nth-child(2) {
        stroke-dasharray: 29 299;
      }
      .burguer path:nth-child(3) {
        transform-origin: 35% 63%;
      }
      .burguer path:nth-child(4) {
        stroke-dasharray: 29 299;
      }
      .burguer path:nth-child(5) {
        transform-origin: 61% 52%;
      }
      .burguer path:nth-child(6) {
        transform-origin: 62% 52%;
      }
      .burguer.active path:nth-child(1) {
        transform: translateX(9px) translateY(1px) rotate(45deg);
      }
      .burguer.active path:nth-child(2) {
        stroke-dasharray: 225 299;
        stroke-dashoffset: -72px;
      }
      .burguer.active path:nth-child(3) {
        transform: translateX(9px) translateY(1px) rotate(-45deg);
      }
      .burguer.active path:nth-child(4) {
        stroke-dasharray: 225 299;
        stroke-dashoffset: -72px;
      }
      .burguer.active path:nth-child(5) {
        transform: translateX(9px) translateY(1px) rotate(-45deg);
      }
      .burguer.active path:nth-child(6) {
        transform: translateX(9px) translateY(1px) rotate(45deg);
      }

      .burguer.safari {
        zoom: reset;
      }

      .burguer.safari svg {
        width: 72px;
        height: 72px;
      }
    </style>
    <script>
        var ua = navigator.userAgent.toLowerCase(); 
        if (ua.indexOf('safari') != -1) { 
          if (ua.indexOf('chrome') <= -1) {
            document.getElementById('burguer-menu').classList.add('safari');
          }
        }
    </script>
    
    </div>
		</header>
		<aside class="sidenav sidenav-smalls">
			<?php get_template_part('parts/menu/menu'); ?>
		</aside>
		<main class="main">