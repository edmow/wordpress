<?php
/*
Template Name: Rede Credênciada
*/
?>
<?php get_header(); ?>
<?php get_template_part('parts/btn-whatsapp/whatsapp') ?>
<?php
	$exibir_introducao = get_field('exibir_introducao');
	$introducao_titulo = get_field('introducao_titulo');
	$introducao_descricao = get_field('introducao_descricao');
	$introducao_imagem_de_fundo = get_field('introducao_imagem_de_fundo');

	$exibir_credenciados = get_field('exibir_credenciados');
	$exibir_busca_e_filtro = get_field('exibir_busca_e_filtro');

	$exibir_formulario = get_field('exibir_formulario');
	$formulario_imagem = get_field('formulario_imagem');
	$formulario_titulo = get_field('formulario_titulo');
	$formulario_descricao = get_field('formulario_descricao');

	$exibir_informacoes = get_field('exibir_informacoes');
	$informacoes_imagem = get_field('informacoes_imagem');
	$informacoes_subtitulo = get_field('informacoes_subtitulo');
	$informacoes_titulo = get_field('informacoes_titulo');
	$informacoes_descricao = get_field('informacoes_descricao');

	$exibir_cta = get_field('exibir_cta');
	$chamada_form_cta = get_field('chamada_form_cta');
	$titulo_form_cta = get_field('titulo_form_cta');
	$texto_form_cta = get_field('texto_form_cta');
	$imagem_form_cta = get_field('imagem_form_cta');
	$link_form_cta = get_field('link_form_cta');
?>
<div id="page-content">
	<?php if ( $exibir_introducao ): ?>
		<div id="introducao" style="background-image: url(<?php echo $introducao_imagem_de_fundo['url']; ?>);">
			<div class="box-texto">
				<?php if ( $introducao_titulo ): ?>
					<h1><?php echo $introducao_titulo; ?></h1>
				<?php endif ?>
				<?php if ( $introducao_descricao ): ?>
					<?php echo $introducao_descricao; ?>
				<?php endif ?>
			</div>
		</div>
	<?php endif ?>
	<?php if ( $exibir_credenciados ): ?>
		<?php if ( $exibir_busca_e_filtro ): ?>
			<div id="busca-filtro">
				<div class="busca">
					<form>
						<input type="text" name="busca" placeholder="Buscar por..." value="<?php echo $_GET['busca']; ?>" required>
						<button type="submit">
							<span class="texto">Buscar</span>
							<span class="icone"><?php echo file_get_contents(get_svg('icon-search')); ?></span>
						</button>
					</form>
				</div>
				<div class="filtro">
					<?php
						$servicos = get_terms( array(
							'taxonomy' => 'tipo-de-servico',
							'hide_empty' => true
						) );
					?>
					<select name="filtro" onchange="filtrar(this);">
						<option selected disabled>Filtrar por...</option>
						<?php foreach ($servicos as $key => $value): ?>
							<option value="<?php echo $value->slug; ?>" <?php if( $_GET['filtro'] == $value->slug ){ echo 'selected'; } ?>><?php echo $value->name; ?></option>
						<?php endforeach ?>
					</select>
					<script type="text/javascript">
						function filtrar(this_dom){
							var filtrar_por = jQuery(this_dom).val();
							window.location.href = "<?php echo get_the_permalink(); ?>?filtro="+filtrar_por;
						}
					</script>
				</div>
			</div>
		<?php endif ?>
		<div id="credenciados">
			<?php
				$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
			
				$args = array(
					'post_type' => 'credenciado',
					'posts_per_page' => 6,
					'paged' => $paged
				);
				if( $_GET['busca'] && !empty($_GET['busca']) ){
					$args['s'] = $_GET['busca'];
				}
				if( $_GET['filtro'] && !empty($_GET['filtro']) ){
					$args['tax_query'] =  array(
				        array (
				            'taxonomy' => 'tipo-de-servico',
				            'field' => 'slug',
				            'terms' => $_GET['filtro'],
				        )
				    );
				}
			
				$wp_query = new WP_Query( $args );
			?>
			
			<?php if ( $wp_query->have_posts() ): ?>
				<div class="content">
					<?php while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>
						<?php
							$credenciado_id = get_the_ID();
							$credenciado_titulo = get_the_title();
							$credenciado_logotipo = get_field('logotipo');
							$credenciado_descricao = get_field('descricao');
							$credenciado_tag = get_field('tag');
							$credenciado_link = get_field('link');
						?>
					
						<div class="credenciado">
							<div class="content">
								<?php if ( $credenciado_logotipo ): ?>
									<img src="<?php echo $credenciado_logotipo['sizes']['medium']; ?>" class="logotipo" alt="Logotipo <?php echo $credenciado_titulo; ?>">
								<?php endif ?>
								<?php if ( $credenciado_tag ): ?>
									<span class="tag"><?php echo $credenciado_tag; ?></span>
								<?php endif ?>
								<?php if ( $credenciado_descricao ): ?>
									<p class="descricao"><?php echo $credenciado_descricao; ?></p>
								<?php endif ?>
								<a href="<?php echo $credenciado_link; ?>" target="_blank">
									<img src="<?php echo get_svg('link-credenciado'); ?>">
								</a>
							</div>
						</div>
					<?php endwhile; ?>	
				</div>
				<div class="paginacao">
				    <?php wordpress_pagination(); ?>
				</div>
				<?php wp_reset_postdata(); ?>
			<?php else: ?>
				<pre>Nada encontrado!</pre>
			<?php endif ?>
		</div>
	<?php endif ?>

	<?php if ( $exibir_cta ): ?>
		<div class="contact-cta">
			<?php if ($link_form_cta) : ?>
				<a class="contact-cta-link" href="<?php echo $link_form_cta['url'] ?>" target="<?php echo $link_form_cta['target'] ?>"><span><?php echo $link_form_cta['title'] ?></span></a>
			<?php endif; ?>
			<div class="left">
				<span><?php echo $chamada_form_cta ?></span>
				<h2><?php echo $titulo_form_cta ?></h2>
				<p><?php echo $texto_form_cta ?></p>
			</div>
			<div class="right">
				<img src="<?php echo $imagem_form_cta ?>" alt="">
			</div>
		</div>
	<?php endif ?>

	<?php if ( $exibir_formulario || $exibir_informacoes ): ?>
		<div id="formulario-e-informacoes">
			<?php if ( $exibir_formulario ): ?>
				<div class="formulario">
					<?php if ( $formulario_imagem ): ?>
						<img src="<?php echo $formulario_imagem['sizes']['medium']; ?>">
					<?php endif ?>
					<?php if ( $formulario_titulo ): ?>
						<h2><?php echo $formulario_titulo; ?></h2>
					<?php endif ?>
					<?php if ( $formulario_descricao ): ?>
						<p><?php echo $formulario_descricao; ?></p>
					<?php endif ?>
					<?php echo do_shortcode('[contact-form-7 id="79fef37" title="Rede Credenciada"]'); ?>
				</div>
			<?php endif ?>
			<?php if ( $exibir_informacoes ): ?>
				<div class="informacoes">
					<?php if ( $informacoes_imagem ): ?>
						<img src="<?php echo $informacoes_imagem['sizes']['large']; ?>">
					<?php endif ?>
					<?php if ( $informacoes_subtitulo ): ?>
						<h3><?php echo $informacoes_subtitulo; ?></h2>
					<?php endif ?>
					<?php if ( $informacoes_titulo ): ?>
						<h2><?php echo $informacoes_titulo; ?></h2>
					<?php endif ?>
					<?php if ( $informacoes_descricao ): ?>
						<div class="descricao">
							<?php echo $informacoes_descricao; ?>
						</div>
					<?php endif ?>
				</div>
			<?php endif ?>
		</div>
	<?php endif ?>
</div>
<?php get_footer(); ?>
<script>
$(document).ready(function() {
  $(".contact-cta").click(function(){
    var url = $(".contact-cta-link").attr("href");
    window.location.href = url;
  });
});
</script>