<?php

/*

Template Name: Fale Conosco

*/

?>



<?php get_header();



$chamada_form = get_field('chamada_form');

$titulo_form = get_field('titulo_form');

$texto_form = get_field('texto_form');



$chamada_form_cta = get_field('chamada_form_cta');

$titulo_form_cta = get_field('titulo_form_cta');

$texto_form_cta = get_field('texto_form_cta');

$imagem_form_cta = get_field('imagem_form_cta');

$link_form_cta = get_field('link_form_cta');

?>

<?php get_template_part('parts/btn-whatsapp/whatsapp') ?>

<div class="contact-content">

    <div class="contact-form">

        <div class="left">

            <span><?php echo $chamada_form ?></span>

            <h1><?php echo $titulo_form ?></h1>

            <p><?php echo $texto_form ?></p>
            <div class="contacts-novale">
                <div>
                    <div><?php echo file_get_contents(get_svg('email')); ?></div> <a href="mailto:secretaria@novalehub.com.br">secretaria@novalehub.com.br</a>
                </div>
                <div>
                    <div><?php echo file_get_contents(get_svg('telefone')); ?></div> <a href="tel:4733075374"> (47) 3307-5374</a>
                </div>
            </div>

            <div>
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d34975.22458617755!2d-49.134742676905226!3d-26.466685780211705!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94de940788cdb62d%3A0x53675546db3d967!2sNovale%20Hub%20-%20Centro%20de%20Inova%C3%A7%C3%A3o%20Jaragu%C3%A1%20do%20Sul!5e0!3m2!1spt-BR!2sbr!4v1707311765166!5m2!1spt-BR!2sbr" 
                width="100%" 
                height="300" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
            </div>
        </div>

        <div class="right">

            <?php echo do_shortcode('[contact-form-7 id="e0c21c2" title="Fale Conosco"]') ?>

        </div>

    </div>

    <div class="contact-cta">

        <?php if ($link_form_cta) : ?>

            <a href="<?php echo $link_form_cta['url'] ?>" target="<?php echo $link_form_cta['target'] ?>"><span><?php echo $link_form_cta['title'] ?></span></a>

        <?php endif; ?>

        <div class="left">

            <span><?php echo $chamada_form_cta ?></span>

            <h2><?php echo $titulo_form_cta ?></h2>

            <p><?php echo $texto_form_cta ?></p>

        </div>

        <div class="right">

            <img src="<?php echo $imagem_form_cta ?>" alt="">

        </div>

    </div>

</div>

<?php get_footer(); ?>