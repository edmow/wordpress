<?php
/*
Template Name: Trabalhe conosco
*/
?>

<?php get_header();

$chamada_work_cta = get_field('chamada_work_cta');
$titulo_work_cta = get_field('titulo_work_cta');
$texto_work_cta = get_field('texto_work_cta');
$imagem_work_cta = get_field('imagem_work_cta');

$titulo_work = get_field('titulo_work');
$texto_work = get_field('texto_work');
?>

<div class="work-content">
    <div class="work-cta">
        <div class="left">
            <span><?php echo $chamada_work_cta ?></span>
            <h1><?php echo $titulo_work_cta ?></h1>
            <p><?php echo $texto_work_cta ?></p>
        </div>
        <div class="right">
            <img src="<?php echo $imagem_work_cta ?>" alt="">
        </div>
    </div>
    <div class="work-form">
        <div class="float-icon">
            <img src="<?php echo get_svg('double-arrow'); ?>" alt="Icone seta">
        </div>
        <div class="left">
            <h3><?php echo $titulo_work ?></h3>
            <p><?php echo $texto_work ?></p>
        </div>
        <div class="right">
            <?php echo do_shortcode('[contact-form-7 id="12bc988" title="Trabalhe conosco"]') ?>
        </div>
    </div>
</div>
<?php get_footer(); ?>