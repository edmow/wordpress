<?php get_header(); ?>
    <div class="content">
        <?php
            get_template_part('parts/materiais/loop');
            get_template_part('parts/materiais/download');
            get_template_part('parts/materiais/links-uteis');
        ?> 
    </div>
<?php get_footer(); ?> 