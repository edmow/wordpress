$(document).ready(function(){

    $(".city-button").click(function(){

        $(".city-data").addClass("active");

        $(".state-data").removeClass("active");

        $(".state-button").removeClass("active");

        $(this).addClass("active");

    });

    $(".state-button").click(function(){

        $(".state-data").addClass("active");

        $(".city-data").removeClass("active");

        $(".city-button").removeClass("active");

        $(this).addClass("active");

    });

    // Animação Numeros
    const counters = document.querySelectorAll('.labbo-number');
    const speed = 200;

    counters.forEach( counter => {
    const animate = () => {
        const value = +counter.getAttribute('labbo');
        const data = +counter.innerText;
        
        const time = value / speed;
        if(data < value) {
            counter.innerText = Math.ceil(data + time);
            setTimeout(animate, 1);
            }else{
            counter.innerText = value;
            }
        
    }
    
    animate();
    });

});



function generateGraphicAllCompanies(){

    var yearLabels = labels.map(function(date) {

        return date.slice(-4); // Pegar apenas os últimos 4 caracteres (ano) da data

    });



    var datasets = allLines.map(function(lineData) {

        return {

            label: 'Valores',

            data: labels.map(function(date) {

                return lineData[date] ? lineData[date]['values'] : null;

            }),

            borderColor: Object.values(lineData).find(val => val !== null)['color'],

            tension: 0.4

        };

    });





    var ctx = document.getElementById('graphic-all-companies').getContext('2d');

    var myChart = new Chart(ctx, {

        type: 'line',

        data: {

            labels: labels, // Manter os rótulos originais

            datasets: datasets

        },

        options: {

            scales: {

                x: {

                    grid: {

                        display: false // Oculta as linhas verticais do eixo x

                    },

                    ticks: {

                        callback: function(value, index, values) {

                            return yearLabels[index]; // Exibir apenas os últimos 4 caracteres (ano) no eixo x

                        }

                    }

                },

                y: {

                    ticks: {

                        display: false

                    }

                }

            },

            plugins: {

                legend: {

                    display: false

                },

                tooltip: {

                    enabled: true,

                    mode: 'nearest',

                    intersect: false,

                    backgroundColor: '#fff',

                    titleFont: {

                        size: 20,

                        weight: '400',

                        family: 'Plus Jakarta Sans',

                    },

                    bodyFont: {

                        size: 28,

                        weight: '700',

                        family: 'Plus Jakarta Sans',

                    },

                    borderWidth: 1,

                    borderColor: '#f0f2f5',

                    displayColors: false,

                    bodyColor: '#000',

                    titleColor: '#667085',

                    callbacks: {

                        label: function(context) {

                            var value = context.dataset.data[context.dataIndex];

                            return formatToReal(value);

                        }

                    }

                }

            }

        }

    });

}



function generateGraphicDistribution(){

    var ctx = document.getElementById('graphic-companies').getContext('2d');

    var graphicCompanies = new Chart(ctx, { 

        type: 'bar',

        data: {

            labels: datesCompanies,

            datasets: [{

                label: 'Valores',

                data: valuesCompanies,

                backgroundColor: color, 

                borderWidth: 1

            }]

        },

        options: {

            animation: false,

            barPercentage: 0.2,

            categorySpacing: 10, 

            scales: {

                    x: {

                        grid: {

                            display: false,

                        },

                        ticks: {

                            stepSize: 2

                        }

                    },

                    y: {

                        ticks: {

                            display: false,

                            stepSize: 300

                        }

                    }

                },

                plugins: {

                    legend: {

                        display: false

                    },

                    tooltip: {

                        enabled: true,

                        mode: 'nearest',

                        intersect: false,

                        backgroundColor: '#fff',

                        titleFont: {

                            size: 18,

                            weight: '400',

                            family: 'Plus Jakarta Sans',

                        },

                        bodyFont: {

                            size: 14,

                            weight: '700',

                            family: 'Plus Jakarta Sans',

                        },

                        borderWidth: 1,

                        borderColor: '#f0f2f5',

                        displayColors: false,

                        bodyColor: '#000',

                        titleColor: '#E94562',

                        callbacks: {

                            label: function(context) {

                                var valueCompanies = context.dataset.data[context.dataIndex];

                            return valueCompanies + ' Empresa';

                            }

                        }

                    }

                }

        }

    });

}

function generateGraphicGender(){

    var ctx = document.getElementById('graphic-gender').getContext('2d');

    var myChart = new Chart(ctx, {

        type: 'doughnut', // Tipo de gráfico de rosca

        data: {

            labels: valueGender,

            datasets: [{

                data: numberGender,

                backgroundColor: colorGender,

            }]

        },

        options: {

            animation: false,

            responsive: true,

            plugins: {

                legend: {

                    display: true,

                    position: 'bottom',

                    align: 'center', // Centraliza as legendas

                    labels: {

                        padding: 10

                    }

                }

            },

        }

    });

}



function generateGraphicGender(){

    var ctx = document.getElementById('graphic-gender').getContext('2d');

        var myChart = new Chart(ctx, {

            type: 'doughnut', // Tipo de gráfico de rosca

            data: {

                labels: valueGender,

                datasets: [{

                    data: numberGender,

                    backgroundColor: colorGender,

                    borderWidth: 1

                }]

            },

            options: {

                responsive: true,

                plugins: {

                    legend: {

                        display: true,

                        position: 'bottom',

                        align: 'center', // Centraliza as legendas

                        labels: {

                            padding: 10,

                            pointStyle: "circle", usePointStyle: true 

                             

                        }

                    }

                }

            }

        });

 

}



function generateGraphicProfile(){

    var ctx = document.getElementById('graphic-profile');

    ctx.style.maxHeight = '260px'; // Defina a altura máxima desejada

    var myChart = new Chart(ctx, {

        type: 'pie', // Tipo de gráfico de pizza

        data: {

            labels: valueProfile,

            datasets: [{

                data: numberProfile,

                backgroundColor: colorProfile,

                borderWidth: 0

            }]

        },

        options: {

            animation: false,

            responsive: true,

            plugins: {

                legend: {

                    display: true,

                    position: 'bottom',

                    align: 'center',

                    labels: {

                        padding: 10,

                        pointStyle: "circle",

                        usePointStyle: true 

                    }

                },

            }

        }

    });

}



$(document).ready(function() {

    // Verifica a largura da janela ao carregar a página

    if ($(window).width() < 1200) {

        if ($(window).width() < 1200) {

            $('.age-range-first').text('');

        } else {

            $('.age-range-first').text($('.age-range-first').data('value'));

        }

    }



    // Evento que é acionado quando a janela é redimensionada

    $(window).resize(function() {

        // Verifica a largura da janela durante o redimensionamento

        if ($(window).width() < 1200) {

            $('.age-range-first').text('');

        } else {

            $('.age-range-first').text($('.age-range-first').data('value'));

        }

    });

});