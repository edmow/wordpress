$(document).ready(function () {
  /**
   * Cidade estado
   */
  $("#select_cidade").html("<option value>Sua cidade</option>");
  if ($("#select_estado").length > 0) {
    new dgCidadesEstados({
      cidade: document.getElementById("select_cidade"),
      estado: document.getElementById("select_estado"),
    });
  }
  /**
   * Phone mask
   */
  const $input = document.querySelector("#telMask");
  $input.addEventListener("input", handleInput, false);
  function handleInput(e) {
    e.target.value = phoneMask(e.target.value);
  }
  function phoneMask(phone) {
    return phone
      .replace(/\D/g, "")
      .replace(/^(\d)/, "($1")
      .replace(/^(\(\d{2})(\d)/, "$1) $2")
      .replace(/(\d{4})(\d{1,5})/, "$1-$2")
      .replace(/(-\d{5})\d+?$/, "$1");
  }
  // Track Contato
  var contatoForm = document.querySelector("#wpcf7-f7-o1");
  contatoForm.addEventListener(
    "wpcf7mailsent",
    function (event) {
      ga("contato", "form", "enviar");
    },
    false
  );
});
function formatToReal(value) {
  return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
  }).format(value);
}
$(document).ready(function () {
    var prev = 0;
    var $window = $(window);
    var nav = $('.header');
  
    function toggleNav() {
      // Verifica se a largura da tela é menor que 991px
      if ($window.width() < 991) {
        var scrollTop = $window.scrollTop();
        nav.toggleClass('hidden-bar', scrollTop > prev);
        prev = scrollTop;
      }
    }
  
    // Executa a função no carregamento inicial
    toggleNav();
  
    // Executa a função sempre que a janela é redimensionada
    $window.on('resize', toggleNav);
  
    // Executa a função durante o scroll
    $window.on('scroll', toggleNav);
  });