<?php
/*
Template Name: Faça Parte - Rede Credênciada
*/
?>
<?php get_header(); ?>
<?php get_template_part('parts/btn-whatsapp/whatsapp') ?>
<?php
	$exibir_introducao = get_field('exibir_introducao');
	$introducao_titulo = get_field('introducao_titulo');
	$introducao_descricao = get_field('introducao_descricao');
	$introducao_imagem_de_fundo = get_field('introducao_imagem_de_fundo');

	$exibir_formulario = get_field('exibir_formulario');
	$formulario_imagem = get_field('formulario_imagem');
	$formulario_titulo = get_field('formulario_titulo');
	$formulario_descricao = get_field('formulario_descricao');

	$exibir_informacoes = get_field('exibir_informacoes');
	$informacoes_imagem = get_field('informacoes_imagem');
	$informacoes_subtitulo = get_field('informacoes_subtitulo');
	$informacoes_titulo = get_field('informacoes_titulo');
	$informacoes_descricao = get_field('informacoes_descricao');
?>
<div id="page-content">
	<?php if ( $exibir_introducao ): ?>
		<div id="introducao" style="background-image: url(<?php echo $introducao_imagem_de_fundo['url']; ?>);">
			<div class="box-texto">
				<?php if ( $introducao_titulo ): ?>
					<h1><?php echo $introducao_titulo; ?></h1>
				<?php endif ?>
				<?php if ( $introducao_descricao ): ?>
					<?php echo $introducao_descricao; ?>
				<?php endif ?>
			</div>
		</div>
	<?php endif ?>

	<?php if ( $exibir_formulario || $exibir_informacoes ): ?>
		<div id="formulario-e-informacoes">
			<?php if ( $exibir_formulario ): ?>
				<div class="formulario">
					<?php if ( $formulario_imagem ): ?>
						<img src="<?php echo $formulario_imagem['sizes']['medium']; ?>">
					<?php endif ?>
					<?php if ( $formulario_titulo ): ?>
						<h2><?php echo $formulario_titulo; ?></h2>
					<?php endif ?>
					<?php if ( $formulario_descricao ): ?>
						<p><?php echo $formulario_descricao; ?></p>
					<?php endif ?>
					<?php echo do_shortcode('[contact-form-7 id="79fef37" title="Rede Credenciada"]'); ?>
				</div>
			<?php endif ?>
			<?php if ( $exibir_informacoes ): ?>
				<div class="informacoes">
					<?php if ( $informacoes_imagem ): ?>
						<img src="<?php echo $informacoes_imagem['sizes']['large']; ?>">
					<?php endif ?>
					<?php if ( $informacoes_subtitulo ): ?>
						<h3><?php echo $informacoes_subtitulo; ?></h2>
					<?php endif ?>
					<?php if ( $informacoes_titulo ): ?>
						<h2><?php echo $informacoes_titulo; ?></h2>
					<?php endif ?>
					<?php if ( $informacoes_descricao ): ?>
						<div class="descricao">
							<?php echo $informacoes_descricao; ?>
						</div>
					<?php endif ?>
				</div>
			<?php endif ?>
		</div>
	<?php endif ?>
</div>
<?php get_footer(); ?>