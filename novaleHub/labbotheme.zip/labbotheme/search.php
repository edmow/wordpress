<?php
/*
Template Name: Resultado - Blog
*/
?>
<?php get_header(); ?>
<div class="content">
    <div class="content-inner result-inner">
        <?php get_template_part('parts/blog/filter'); ?>
        <?php get_template_part('parts/blog/result/loop'); ?>
        <?php get_template_part('parts/blog/newsletter'); ?>
    </div>
</div>
<?php get_footer(); ?>