<?php

/*

Template Name: Programa

*/

?>



<?php get_header(); ?>

<?php get_template_part('parts/btn-whatsapp/whatsapp') ?>

<?php

// Controle de seções

$mostrar_sobre = get_field('mostrar_secao_sobre');

$mostrar_resultados = get_field('mostrar_secao_resultados');

$mostrar_ctas = get_field('mostrar_secao_ctas');

$mostrar_faq = get_field('mostrar_secao_faq');

$mostrar_parceiros = get_field('mostrar_secao_parceiros');

$mostrar_form = get_field('mostrar_secao_form');



// Banner

$chamada_program_banner = get_field('chamada_program_banner');

$titulo_program_banner = get_field('titulo_program_banner');

$texto_program_banner = get_field('texto_program_banner');

$imagem_program_banner = get_field('imagem_program_banner');



// About

$icone_program_about = get_field('icone_sobre_programa');

$titulo_program_about = get_field('titulo_sobre_programa');

$texto_program_about = get_field('texto_sobre_programa');

$marca_program_about = get_field('marca_sobre_programa');

$imagem_menor_program_about = get_field('imagem_destaque_menor');

$imagem_maior_program_about = get_field('imagem_destaque_maior');



// Results

$icone_program_results = get_field('icone_resultados_programa');

$titulo_program_results = get_field('titulo_resultados_programa');

$program_results = get_field('resultados_programa');



// CTAS

$primeira_cta_program = get_field('primeira_cta');

$segunda_cta_program = get_field('segunda_cta');

$terceira_cta_program = get_field('terceira_cta');



// FAQ

$chamada_faq = get_field('chamada_faq');

$titulo_faq = get_field('titulo_faq');

$loop_faq = get_field('faq_programa');

$image_faq = get_field('imagem_faq');



// Partners

$titulo_parceiros = get_field('titulo_parceiros');

$parceiros_programa = get_field('parceiros_programa');



// FORM

$shortcode_form = get_field('shortcode');

?>



<div class="program">

    <div class="program-banner" style="background:url(<?php echo $imagem_program_banner['url'] ?>);">

        <span><?php echo $chamada_program_banner ?></span>

        <h1><?php echo $titulo_program_banner ?></h1>

        <p><?php echo $texto_program_banner ?></p>

        <div class="float-icon">

            <img src="<?php echo get_svg('double-arrow'); ?>" alt="Icone seta">

        </div>

    </div>

    <?php if ($mostrar_sobre) : ?>

        <div class="about">

            <div class="left">

                <img src="<?php echo $icone_program_about ?>" alt="<?php echo $titulo_program_about ?>">

                <h2><?php echo $titulo_program_about ?></h2>

                <p><?php echo $texto_program_about ?></p>

            </div>

            <div class="right">

                <span><?php echo $marca_program_about ?></span>

                <img class="img-small" src="<?php echo $imagem_menor_program_about ?>" alt="Imagem Sobre">

                <img class="img-big" src="<?php echo $imagem_maior_program_about ?>" alt="Imagem Sobre 2">

            </div>

        </div>

    <?php endif; ?>



    <?php if ($mostrar_resultados) : ?>

        <div class="results">

            <img src="<?php echo $icone_program_results ?>" alt="Icone resultados">

            <h2><?php echo $titulo_program_results ?></h2>

            <div class="results-main">

                <?php foreach ($program_results as $result) : ?>

                    <div class="result">

                        <span><?php echo $result['valor'] ?></span>

                        <p><?php echo $result['descricao'] ?></p>

                    </div>

                <?php endforeach ?>

            </div>

        </div>

    <?php endif; ?>



    <?php if ($mostrar_ctas) : ?>

        <div class="join">

            <div class="left">

                <?php if ($primeira_cta_program['imagem']) : ?>

                    <img class="img-cta-1" src="<?php echo $primeira_cta_program['imagem'] ?>" alt="">

                <?php else : ?>

                    <img src="<?php echo get_svg('default-blue'); ?>" alt="Sem imagem">

                <?php endif; ?>

            </div>

            <div class="right">

                <span><?php echo $primeira_cta_program['chamada'] ?></span>

                <h2><?php echo $primeira_cta_program['titulo'] ?></h2>

                <p><?php echo $primeira_cta_program['texto'] ?></p>

                <?php if ($primeira_cta_program['link']) : ?>

                    <a href="<?php echo $primeira_cta_program['link']['url'] ?>" target="<?php echo $primeira_cta_program['link']['target'] ?>"><?php echo $primeira_cta_program['link']['title'] ?> <img src="<?php echo get_svg('btn-check'); ?>" alt=""></a>

                <?php endif; ?>

            </div>

        </div>

        <div class="investors">

            <div class="left">

                <figure>

                    <img src="<?php echo $segunda_cta_program['imagem'] ?>" alt="">

                </figure>

            </div>

            <div class="right">

                <span><?php echo $segunda_cta_program['chamada'] ?></span>

                <h2><?php echo $segunda_cta_program['titulo'] ?></h2>

                <p><?php echo $segunda_cta_program['texto'] ?></p>

                <?php if ($segunda_cta_program['link']) : ?>

                    <a href="<?php echo $segunda_cta_program['link']['url'] ?>" target="<?php echo $segunda_cta_program['link']['target'] ?>"><?php echo $segunda_cta_program['link']['title'] ?> <img src="<?php echo get_svg('btn-check'); ?>" alt=""></a>

                <?php endif; ?>

            </div>

        </div>

        <div class="startup">

            <div class="left">

                <figure>

                    <img src="<?php echo $terceira_cta_program['imagem'] ?>" alt="">

                </figure>

            </div>

            <div class="right">

                <span><?php echo $terceira_cta_program['chamada'] ?></span>

                <h2><?php echo $terceira_cta_program['titulo'] ?></h2>

                <p><?php echo $terceira_cta_program['texto'] ?></p>

                <?php if ($terceira_cta_program['link']) : ?>

                    <a href="<?php echo $terceira_cta_program['link']['url'] ?>" target="<?php echo $terceira_cta_program['link']['target'] ?>"><?php echo $terceira_cta_program['link']['title'] ?> <img src="<?php echo get_svg('btn-check'); ?>" alt=""></a>

                <?php endif; ?>

            </div>

        </div>

    <?php endif; ?>



    <?php if ($mostrar_faq) : ?>

        <div class="faq">

            <div class="left">

                <span><?php echo $chamada_faq ?></span>

                <h2><?php echo $titulo_faq ?></h2>

                <div class="faq-loop">

                    <?php foreach ($loop_faq as $faq_item) : ?>

                        <details class="faq-item">

                            <summary>

                                <span class="expand-icon"></span>

                                <?php echo $faq_item['pergunta'] ?>

                            </summary>

                            <p><?php echo $faq_item['resposta'] ?></p>

                        </details>

                        <div class="faq-divider"></div>

                    <?php endforeach; ?>

                </div>

            </div>

            <div class="right">

                <img src="<?php echo $image_faq ?>" alt="">

            </div>

        </div>

    <?php endif; ?>



    <?php if ($mostrar_parceiros) : ?>

        <div class="partners">

            <h2><?php echo $titulo_parceiros ?></h2>

            <div class="loop-partners">

                <?php foreach ($parceiros_programa as $image_item) : ?>

                    <div class="image-item">

                        <?php if ($image_item['link']) : ?>

                            <a href="<?php echo $image_item['link'] ?>" target="_blank">

                                <img src="<?php echo $image_item['logo'] ?>" alt="Imagem">

                            </a>

                        <?php else : ?>

                            <img src="<?php echo $image_item['logo'] ?>" alt="Imagem">

                        <?php endif; ?>

                    </div>

                <?php endforeach; ?>

            </div>

        </div>

    <?php endif; ?>



    <?php if ($mostrar_form) : ?>

        <div class="form">

            <?php echo do_shortcode($shortcode_form) ?>

        </div>

    <?php endif; ?>

</div>



<?php get_footer(); ?>